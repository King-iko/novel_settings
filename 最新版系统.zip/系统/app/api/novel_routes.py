from flask import Blueprint, request, jsonify
from ..services.novel_service import novel_service

bp = Blueprint('novels', __name__, url_prefix='/api/novels')

@bp.route('', methods=['POST'])
def create_novel():
    data = request.get_json()
    if not data or 'title' not in data:
        return jsonify({"error": "Title is required"}), 400
    
    novel = novel_service.create_novel(data['title'], data.get('author', ''))
    return jsonify(novel), 201

@bp.route('', methods=['GET'])
def get_novels():
    novels = novel_service.get_all_novels()
    return jsonify(novels)

@bp.route('/<int:novel_id>', methods=['DELETE'])
def delete_novel(novel_id):
    success = novel_service.delete_novel(novel_id)
    if success:
        return jsonify({"message": "Novel deleted successfully"})
    else:
        return jsonify({"error": "Novel not found"}), 404
