from flask import Blueprint, jsonify, request
from ..services.setting_service import setting_service

bp = Blueprint('visualization', __name__, url_prefix='/api/novels')

@bp.route('/<int:novel_id>/chapters/<int:chapter_number>/knowledge_graph', methods=['GET'])
def get_knowledge_graph(novel_id, chapter_number):
    # 从查询参数获取 n，默认值为 1
    n = request.args.get('n', default=1, type=int)

    settings = setting_service.get_settings_at_chapter(novel_id, chapter_number)
    
    # 使用新的范围查询服务
    if n > 1:
        changes = setting_service.get_changes_in_range(novel_id, chapter_number, n)
        updated_entity_names = changes.get('updated_entity_names', set())
    else: # 兼容旧的单章查询
        changes = setting_service.get_chapter_changes(novel_id, chapter_number)
        updated_entity_names = {e['name'] for e in changes.get('new_entities', [])}
        # Add entities with updated properties
        updated_entity_names.update(p['entity_name'] for p in changes.get('new_properties', []))
        # Add entities with updated relationships
        for r in changes.get('new_relationships', []):
            updated_entity_names.add(r['subject_name'])
            updated_entity_names.add(r['object_name'])

    nodes = []
    links = []
    
    # Entities as nodes
    for entity in settings.get('entities', []):
        is_new = entity['name'] in updated_entity_names
        nodes.append({
            "id": str(entity['id']),
            "name": entity['name'],
            "category": entity['type'],
            "properties": entity.get('properties', {}),
            "is_new": is_new,
            # 向前端传递 start_chapter_id 以便进行更灵活的过滤
            "start_chapter": entity.get('start_chapter_id') 
        })
    
    # Relationships as links
    for rel in settings.get('relationships', []):
        # 为了找到节点的数字ID，我们需要一个从实体名称到ID的映射
        # 注意：这里的实现有一个潜在问题，如果存在同名实体，映射会不准确。
        # 在当前数据模型下，我们假设实体名称是唯一的。
        nodes_map = {n['name']: n['id'] for n in nodes}
        source_id = nodes_map.get(rel['subject'])
        target_id = nodes_map.get(rel['object'])
        
        if source_id and target_id:
            links.append({
                "source": source_id,
                "target": target_id,
                "value": rel['relation']
            })
    
    return jsonify({
        "nodes": nodes,
        "links": links
    })
