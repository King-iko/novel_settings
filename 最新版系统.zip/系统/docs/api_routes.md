# API 路由定义

所有路由均以 `/api` 为前缀。

## 1. 小说管理 (`/app/api/novel_routes.py`)  (url_prefix: `/api/novels`)

- **`POST /api/novels`**
  - 功能: 创建一本新小说。
  - 请求体: `{ "title": "小说标题", "author": "作者" }`
  - 响应: `{ "id": 1, "title": "小说标题", "author": "作者" }`

- **`GET /api/novels`**
  - 功能: 获取小说列表。
  - 响应: `[{ "id": 1, "title": "小说标题", "author": "作者" }, ...]`

- **`DELETE /api/novels/<int:novel_id>`**
  - 功能: 删除小说（数据库级联删除相关数据）。
  - 响应: `{ "message": "Novel deleted successfully" }` 或错误信息。

## 2. 章节与导入（`/app/api/chapter_routes.py` 与 `/app/api/novel_routes`）

- **`POST /api/novels/<int:novel_id>/chapters/batch`**
  - 功能: 批量导入章节。
  - 请求体: `[{ "number": 1, "title": "第一章", "content": "..." }, ...]`
  - 响应: `{ "success_count": N, "errors": [...] }`

- **`POST /api/novels/<int:novel_id>/import_next`**
  - 功能: 自动从本地小说文件导入下一个未导入章节（用于逐章导入场景）。
  - 响应: 成功时返回新导入章节号和提示。

- **`POST /api/novels/<int:novel_id>/chapters/batch_delete`**
  - 功能（当前实现）: 删除从 `start_chapter` 到最新已提取章节的**设定**（并返回提示）。请求体示例: `{ "start_chapter": 5 }`。
  - 注意: 源代码中存在两个同路径的路由定义（先是用于删除章节、后是删除设定的实现），后定义会覆盖前定义，导致行为与早期文档不一致。请在使用时注意该路由当前的实际行为或在代码中修复该重复定义。

- **`POST /api/novels/<int:novel_id>/chapters/delete_latest`**
  - 功能: 删除最新一章并删除从该章开始的设定（章节 + 该章之后的设定）。
  - 响应: `{ "message": "Chapter X and its settings have been deleted." }`

- **`GET /api/novels/<int:novel_id>/chapters`**
  - 功能: 列出章节摘要（id, number, title）并返回 `latest_extracted_chapter`。
  - 响应: `{ "chapters": [...], "latest_extracted_chapter": N }`

- **`GET /api/novels/<int:novel_id>/chapters/<int:chapter_num>/content`**
  - 功能: 返回章节内容和可能的冲突检测结果。
  - 响应: `{ "content": "...", "conflict_result": {...} }`

- **`POST /api/novels/<int:novel_id>/chapters/<int:chapter_num>/detect_conflicts`**
  - 功能: 使用 AI 检测章节与已有设定的冲突并保存结果。
  - 响应: `{ "conflicts": [ { "original_text": "...", "conflicting_setting": "...", "start_chapter": 1, "description": "..." }, ... ] }`

- **`POST /api/novels/<int:novel_id>/chapters/<int:chapter_num>/chat`**
  - 功能: 基于该章节上下文与已有设定，进行 AI 问答。
  - 请求体: `{ "query": "问题文本" }`
  - 响应: `{ "response": "AI 的回答文本" }`

## 3. 设定提取与管理 (`/app/api/setting_routes.py`)

- **`POST /api/novels/<int:novel_id>/chapters/<int:chapter_number>/extract`**
  - 功能: 对指定章节执行一次增量设定提取与数据库更新。
  - 响应: `{ "message": "Settings for chapter X extracted successfully." }`

- **`POST /api/novels/<int:novel_id>/extract_batch`**
  - 功能: 同步批量提取指定区间内的设定（注意：可能为阻塞操作）。
  - 请求体: `{ "start": 1, "end": 10 }`
  - 响应: `{ "message": "Batch extraction completed...", "successful_chapters": [...], "errors": [...] }`

- **`POST /api/novels/<int:novel_id>/extract_to_chapter`**
  - 功能: 从第一个未提取章节开始，自动提取直到指定章号（会尝试自动导入缺失章节）。
  - 请求体: `{ "end_chapter": 20 }`

- **`GET /api/novels/<int:novel_id>/chapters/<int:chapter_number>/settings`**
  - 功能: 获取某章结束时的完整设定（entities, relationships, properties）。

- **`GET /api/novels/<int:novel_id>/chapters/<int:chapter_number>/changes`**
  - 功能: 获取该章发生的增量变化（新增实体、新增属性、新增关系、失效项等）。

## 4. 搜索与建议 (`/app/api/search_routes.py`) (url_prefix: `/api/search`)

- **`GET /api/search/entity_history`**
  - 参数: `novel_id`, `entity_name`, `start_chapter`, `end_chapter`。
  - 功能: 获取实体在指定章节区间内的历史变更（创建、属性变更）。

- **`GET /api/search/suggest`**
  - 参数: `novel_id`, `query`。
  - 功能: 基于模糊匹配返回实体名称建议，用于前端自动补全。

---

> ⚠️ 注意：文档已根据当前代码实现进行更新。若希望修复 `/chapters/batch_delete` 的重复路由或调整接口返回格式，请告知，我可以同时提交代码修改建议或修复补丁。
