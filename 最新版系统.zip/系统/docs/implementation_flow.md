# 完整实现流程

下面根据当前代码实现（`app/services`）说明核心流程与关键实现细节，重点标注与代码行为一致的地方。

## 1. 批量导入章节 (`chapter_service.py`)

- 接收 `POST /api/novels/<novel_id>/chapters/batch`，请求体为章节数组（每项包含 `number`, `title`, `content`）。
- 将插入操作封装为事务（`db_service.execute_transaction`），批量执行 `INSERT INTO chapters ...`。
- 如果事务失败，返回错误；成功则返回 `success_count`。

## 2. 增量提取设定 (`setting_service.py`)

这是系统的核心流程：

1. 数据准备
   - 获取 `current_chapter_id`（通过 `chapters` 表用小说ID+章号定位）。
   - 通过 `get_settings_at_chapter(novel_id, chapter_number - 1)` 获取上一章的“有效”设定（entities/properties/relationships）。
   - 读取当前章节内容。

2. 与 AI 交互
   - 调用 `ai_service.extract_settings_from_text(content, old_settings)`，传入旧设定和章节文本。
   - 期望得到 JSON 字典，至少包含 `new_settings` 与 `invalidated_settings`。

3. 解析并应用到数据库
   - 基于 `new_settings`：插入新实体、插入/更新属性（若属性值变化则把旧记录的 `end_chapter_id` 更新为当前章ID 并新增新记录）。
   - 基于 `invalidated_settings`：将对应记录的 `end_chapter_id` 更新为当前章节 ID（以标记失效）。
   - 以上操作通过 `db_service.execute_transaction` 原子执行。

4. 额外行为
   - 批量提取（`extract_to_chapter` / `extract_batch`）在遇到缺失章节时会尝试调用 `chapter_service.import_from_local_file` 自动从本地小说文件导入所需章节。

## 3. 删除 / 回滚设定

- `delete_latest_chapter_and_settings(novel_id)`（POST `/.../chapters/delete_latest`）会：
  1. 查找最新章节号并删除从该章开始的设定（`setting_service.delete_settings_from_chapter`）。
  2. 删除该章节记录本身（`chapter_service.delete_chapter`）。
- `rollback_settings` 与 `batch_rollback_settings` 提供按范围回滚的能力：将在范围内 `start_chapter_id` 的设定删除，并将 `end_chapter_id` 在范围内的记录恢复为 `NULL`。

## 4. 知识图谱生成（`visualization_routes.py`）

- 支持查询最近 `n` 章内的更新（通过参数 `n`），默认 `n=1`。
- 输出结构包含 `nodes`（实体）与 `links`（关系），并在节点中额外传递 `start_chapter` 以便前端进行更灵活的高亮/过滤。
- 注意：目前实现假设实体名称唯一以便进行 name->id 的映射（代码中对此有备注警告）。

## 5. 设定冲突检测

- `detect_conflicts` 调用 AI 返回的格式为 `{ "conflicts": [ ... ] }`，其中每个冲突项包含原文片段、冲突的设定描述、该设定最早出现的章节号和简要说明。

---

> ⚠️ 注意：在对接前端或编写自动化脚本时，请以 `docs/api_routes.md` 中列出的实际接口路径和返回格式为准。若需要，我可以继续提交一份建议的接口行为修复（例如修复重复路由定义）。

## 1. 批量导入章节 (`chapter_service.py`)

1.  **接收请求**: 从`chapter_routes.py`接收到小说ID和章节列表（包含章节号、标题、内容）。
2.  **数据库操作**:
    -   开启一个数据库事务。
    -   遍历章节列表，对每一个章节：
        -   检查该章节号是否已存在于该小说的`chapters`表中。
        -   如果存在，可以选择跳过或更新。
        -   如果不存在，执行`INSERT`语句将其插入`chapters`表。
    -   提交事务。如果中途发生任何错误，则回滚事务。
3.  **返回响应**: 向路由返回成功或失败的消息。

## 2. 增量提取设定 (`setting_service.py`)

这是系统的核心和最复杂的部分。

1. **获取数据**:
   - 接收小说ID和当前要处理的章节号 `current_chapter_number`。
   - 通过 `get_settings_at_chapter(novel_id, chapter_number - 1)` 获取上一章的有效设定（entities/properties/relationships）。
   - 查询当前章节 `current_chapter_number` 的 `content`。

2. **与 AI 交互 (`ai_service.py`)**:
   - 将旧设定和章节文本传给 `ai_service.extract_settings_from_text`。
   - 期望返回 JSON，至少包含 `new_settings` 与 `invalidated_settings`（**代码不使用 `unchanged_settings`**）。

3. **解析并更新数据库 (`db_service.py`)**:
   - 针对 `invalidated_settings`：设置对应记录的 `end_chapter_id` 为当前章节 ID（或做 DELETE 操作，视实现而定）。
   - 针对 `new_settings`：插入新实体/关系，或在属性变更时更新旧记录的 `end_chapter_id` 并新增新记录（以保留变更历史）。
   - 所有更新通过事务执行（`db_service.execute_transaction`）。

4. **额外注意事项**:
   - 在批量提取（`extract_to_chapter`）的流程中，若遇到缺失的章节，系统会尝试调用 `chapter_service.import_from_local_file` 自动从本地小说文件导入缺失章节，然后继续提取。
   - 返回给前端的响应为一个简洁的摘要（成功章节列表与错误列表）。

3.  **解析并更新数据库 (`db_service.py`)**:
    -   开启数据库事务。
    -   **处理失效设定**:
        -   遍历`invalidated_settings`中的每一项。
        -   根据实体/属性/关系的名称和值，在数据库中找到对应的记录。
        -   将其`end_chapter_id`更新为`current_chapter_id - 1`。
    -   **处理新设定**:
        -   获取当前章节的ID `current_chapter_id`。
        -   遍历`new_settings`中的实体、属性和关系。
        -   将它们作为新记录`INSERT`到相应的表中，`start_chapter_id`设为`current_chapter_id`。
    -   提交事务。

## 3. 删除最新章节 (`chapter_service.py`)

1.  **获取最新章节**:
    -   根据小说ID，查询`chapters`表中`number`最大的章节，获取其ID `latest_chapter_id`。
2.  **回滚设定**:
    -   开启数据库事务。
    -   **删除新设定**: 删除所有`start_chapter_id`等于`latest_chapter_id`的实体、属性和关系记录。
    -   **恢复旧设定**: 找到所有`end_chapter_id`等于`latest_chapter_id - 1`的记录，将它们的`end_chapter_id`重新设为`NULL`。
3.  **删除章节记录**:
    -   从`chapters`表中删除`id`为`latest_chapter_id`的记录。
    -   提交事务。

## 4. 生成知识图谱 (`visualization_service.py`)

1.  **获取设定集**:
    -   接收小说ID和章节号。
    -   查询该章节版本下所有有效的实体、属性和关系。
2.  **格式化数据**:
    -   将实体转换为图的节点（Nodes），格式如`{ "id": entity_id, "name": entity_name, "category": entity_type }`。
    -   将关系转换为图的边（Links），格式如`{ "source": subject_id, "target": object_id, "name": predicate }`。
    -   将实体的属性附加到节点的描述信息中。
3.  **返回数据**: 将格式化后的节点和边列表返回给前端，前端使用ECharts等库进行渲染。

## 5. 检查设定冲突 (`setting_service.py`)

1.  **获取数据**:
    -   获取前一章节的设定集和当前章节的内容。
2.  **与AI交互 (`ai_service.py`)**:
    -   使用`ai_prompts.md`中定义的“设定冲突检测”提示词，将数据发送给AI。
3.  **返回结果**:
    -   解析 AI 返回的 JSON，格式为 `{ "conflicts": [ ... ] }`；将该冲突列表传回前端用于展示和追溯。